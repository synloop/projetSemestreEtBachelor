# Template LaTeX pour le bachelor ISC HEPIA

## Etudiants

**Pour le moment il est seulement possible d'utiliser ce template pour les travaux de semestre et le résumé**.

## Utilisation

Cloner le dépot `ssh://git@ssh.hesge.ch:10572/isc/templates/latex-bachelor.git` ou utiliser le lien fourni sur cyberlearn.

## Compilation

Se placer dans le dossier racine du dépôt et taper la commande:

```
pdflatex Feuille_de_style_memoire_LaTeX.tex
citeproc-lua Feuille_de_style_memoire_LaTeX
pdflatex Feuille_de_style_memoire_LaTeX.tex
pdflatex Feuille_de_style_memoire_LaTeX.tex
```

ou avec lualatex

```
lualatex Feuille_de_style_memoire_LaTeX.tex
lualatex Feuille_de_style_memoire_LaTeX.tex
```

## Questions et bugs

Si vous avez des questions vous pouvez contacter orestis.malaspinas@hesge.ch.

En cas de bug merci d'ouvrir un ticket sur le dépôt git.

Vous pouvez également proposer des merge request, mais il est préférable de me contacter avans afin d'éviter un travail inutile.
