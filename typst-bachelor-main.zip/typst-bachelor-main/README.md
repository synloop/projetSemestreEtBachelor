# Template typst pour le bachelor ISC HEPIA

## Etudiants

**Pour le moment il est seulement possible d'utiliser ce template pour les travaux de semestre et le résumé**.

## Enseignants

Un template pour l'énnoncé du sujet sera disponible prochainement.


## Utilisation

Cloner le dépot `ssh://git@ssh.hesge.ch:10572/isc/templates/typst-bachelor.git` ou utiliser le lien fourni sur cyberlearn.

**Vous ne devez modifier que les fichiers présents dans le dossier template.** Vous êtes toutefois libre d'adopter la hierarchie de dossier que vous souhaitez dans ce dossier.

- Le fichier `semester.typ` du dossier `semester` contient un exemple de travail de semestre.
- Le fichier `abstract.typ` du dossier `abstract` contient un exemple de résumé.

## Compilation

Se placer dans le dossier racine du dépôt et taper la commande:

```
$ typst compile --root . templates/semester/semester.typ
```

Le chemin du template peut-être remplacé par n'importe quel autre template (`abstract/abstract.typ`, etc.).

## Questions et bugs

Si vous avez des questions vous pouvez contacter guillaume.chanel@hesge.ch.

En cas de bug merci d'ouvrir un ticket sur le dépôt git.

Vous pouvez également proposer des merge request, mais il est préférable de me contacter avans afin d'éviter un travail inutile.