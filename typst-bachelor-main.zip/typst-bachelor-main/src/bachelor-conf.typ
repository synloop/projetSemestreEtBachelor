#import "@preview/acrostiche:0.7.0": *

#let month_to_content(m) = {
  return (
    "1": [janvier], "2": [février],  "3": [mars],  "4": [avril],
    "5": [mai], "6": [juin],  "7": [juillet],  "8": [août],
    "9": [setptembre], "10": [octobre], "11": [novembre], "12": [decembre],
  ).at(str(m))
}


#let common-headings(body) = {
  show smallcaps: set text(font: "Roboto") //TODO: could not work with Liberation / Arial find other font ?
  show heading: smallcaps //TODO: this makes the letter numbering also small caps...
  show heading: pad.with(top: 1em, bottom: 1em)
  show heading.where(level: 1): body => {
    pagebreak(weak: true) //TODO: to: "odd" ? If yes then not for starting tables (illustrations+sommaire etc.)
    align(center, body)
  }
  show heading.where(level: 3): pad.with(left: 0.5cm)
  show heading.where(level: 4): pad.with(left: 1cm)  

  body
}


#let unnumbered-headings(body) = {
  show heading: set heading(numbering: none)

  body
}


#let numbered-headings(body) = {
  // Number sections for main document content (except final chapters)
  // TODO: les chapitres apparaisse dans le doc original comme "1. Chapitre 1 :", est-ce vraiment ce que l'on souhaite ?
  // TODO: pour le moment j'ai utiliser seulement "Chapitre 1 :"
  show heading.where(level: 1) : set heading(
    numbering: num => [Chapitre~] + numbering("1", num) + [~:],
    supplement: [Chapitre],
  )
  show heading.where(level: 2): set heading(numbering: "1.1.")
  show heading.where(level: 3): set heading(numbering: (..numbers, last) => numbering("a)", last))

  // For section level 1 the reference only contain the supplement + numbering
  show ref.where(form: "normal"): it => {
    let el = it.element
    if el != none and el.func() == heading and el.level == 1 {
      return link(
        el.location(),
        el.supplement + [~] + numbering(
            "1",
            ..counter(heading).at(el.location())
        )
      )
    } else { return it }
  }

  body
}


#let include_statement(statement) = {  
  if type(statement) == str {
    let isPdf = statement.ends-with(".pdf")
    let isTypst = statement.ends-with(".typ")
    if isPdf {
      return image(statement, width: 100%, height: 92%, fit: "contain")
    } else if isTypst {
      return include(statement)
    }
  }
  panic("statement should be string representing a path to either a .typ or .pdf file")
}


#let title_pages(
  title,
  author,
  illustration,
  orientation,
  date,
  teachers,
  clients
) = {

  set text(font: "Liberation Sans", size: 14pt)

  // Logos
  grid(columns: (1fr,1fr), align: (left, right),
    image("../assets/logo-hepia.svg", width: 66%),
    image("../assets/logo-hes-so-ge.svg", width: 66%)
  )

  align(center+horizon, [

    #v(2fr)

    // Title      
    #text(size: 16pt, strong(upper(title)))
    
    #v(2fr)

    // Illustration
    #block(      
      breakable: false,
      height: 30%,
      illustration.illustration
    )

    #v(3fr)
    
    // Author
    Thèse de bachelor présentée par    
    #v(1fr)
    #strong[#author.firstname #upper(author.lastname)]
    
    #v(1fr)

    // ISC + Orientation
    pour l'obtention du titre Bachelor of Science HES-SO en
    #v(1fr)
    #strong[Informatique et système de communication avec orientation en #orientation]

    #v(2fr)
    
    // Date
    // TODO: why is it Septembre and not the month of the date as in the header ?
    #strong[Septembre #datetime.year(date)]

    #v(3fr)

    #set text(size: 12pt)

    // Teachers and Clients
    #grid(columns: (1fr, 1fr), align: center,
      [
        Professeur-e-s HES responsable-s
        #for t in teachers {
          par(strong(t))
        }
      ],
      [
        
        Mandant-s (si existant-s)
        #for c in clients {
          par(strong(c))
        }
      ]
    )
  ])

  pagebreak()

  set text(size: 12pt, font: "Liberation Serif")
  align(bottom+left)[
    Légende et source de l'illustration de couverture: \
    #illustration.legend-source
  ]

}

#let conf(
  title: none,
  short-title: title => { title },
  author: (
    firstname: none,
    lastname: none,
  ),
  orientation: none,
  teachers: (),
  clients: (),
  illustration: (
    illustration: none,
    legend-source: none,
  ),
  date: datetime.today(),
  dedication: none,
  acknowledgement: none,
  statement: none,
  acronyms: none,
  bibliography-files: none,
  bibliography-style: "iso690-numeric-fr-no-abstract.csl",
  doc,
) = {

  //Configure page and text content
  set page(
    paper: "a4",
    margin: (
      top: 1.5cm,
      bottom: 1.5cm,
      inside: 2.5cm,
      outside: 2cm,      
    ),
  )

  show: common-headings
  show: unnumbered-headings

  set text(font: "Liberation Serif", size: 12pt) // TODO: verify all fonts
  set par(first-line-indent:  (amount: 1cm, all: true), leading: 1em, spacing: 1.75em, justify: true)

  // Two first pages
  title_pages(
    title,
    author,
    illustration,
    orientation,
    date,
    teachers,
    clients
  )

  // Same header for the rest of the doc
  set page(header: text(size: 8pt, fill: gray)[
    #author.lastname, #author.firstname #sym.dash #short-title(title) #sym.dash Thèse BA #sym.dash #month_to_content(date.month()), #date.year()
  ])

  // Footer numbering for introduction pages
  set page(numbering: sym.dash + " i " + sym.dash)


  // Outline
  {
    set text(font: "Liberation Serif")
    show outline.entry.where(level: 1): it => strong(it)
    outline(title: [Table des matières], depth: 3, indent: 2em)
  }

  // Dedication
  if dedication != none {
    page[
      #v(20%)
      #align(right,
        text(font: "Liberation Serif",
          emph(dedication)
        )
      )
    ]
  }

  // Acknowledgements
  if acknowledgement != none [
    = Remerciements
    #acknowledgement
  ]

  if statement != none [
    = Énoncé du sujet
    #include_statement(statement)
  ]

  [
    //TODO decide how this should be done

    = Résumé
  ]

  // Acronyms
  if acronyms != none {
    init-acronyms(acronyms)
    print-index(title: "Liste des acronymes", outlined: true, delimiter: none, row-gutter: 1em, sorted: "down")
  }

  show: numbered-headings

  // Footer numbering for the rest of the document
  set page(numbering: sym.dash + " 1 " + sym.dash)
  counter(page).update(1)

  doc

  show: unnumbered-headings

  if bibliography-files != none {
    bibliography(bibliography-files, style: "../styles/" + bibliography-style, title: [Références documentaires])
  }
}