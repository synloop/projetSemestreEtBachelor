#import "semester-conf.typ": semester
#import "common.typ": sourced_figure, source_url