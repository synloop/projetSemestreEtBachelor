#import "/src/abstract-conf.typ" as abstract

#show: abstract.conf.with(
  title: [Résumé],
  author: [Guillaume Chanel],
  teachers: (
    [Prénom1 Nom1],
    [Prénom2 Nom2],
  ),
  clients: (
    [Entreprise 1],
    [Entreprise 2],
  ),
  illustration: block(height:50pt, stroke: 0.5pt, {
    image("/assets/logos/logo-hepia.svg")
    text(9pt)[_Remplacer tout ce_ `block` \ _par votre illustration (fonction image) \ (image obligatoire)_]
  }),
  date: datetime.today(),
  internship: true,
  confidential: true,
)


Voici mon résumé, je pourrais aussi faire un `include`. #lorem(250) (*250 mots minimum et 300 mots maximum dans la police utilisée pour votre mémoire*).