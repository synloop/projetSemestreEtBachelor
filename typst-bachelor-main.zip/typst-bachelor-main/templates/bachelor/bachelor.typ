#import "conf.typ" as hepia
#import "@preview/acrostiche:0.7.0": *

#show: hepia.conf.with(
  title: [Titre de votre mémoire de Bachelor],
  author: (
    firstname: [Prénom],
    lastname: [Nom]
  ),
  illustration: (
    illustration: block(height:100%, stroke: 0.5pt, {
      image("../assets/logo-hepia.svg")
      text(9pt)[_Remplacer tout ce_ `block` \ _par votre illustration (fonction image) \ (image non obligatoire)_]
    }),
    legend-source: [Indiquer légende et source de l'image de couverture ici],
  ),
  teachers: (
    [Prénon1 Nom1],
    [Prénon2 Nom2],
  ),
  clients: (
    [Prénon1 Nom1],
    [Prénon2 Nom2],
  ),
  orientation: [Nom complet de votre orientation],
  dedication: [Cette thèse de bachelor est dédiée à ma maman que j'aime fort],
  acknowledgement: [En plus de ma maman je remercie mon superviseur adoré.],
  statement: none, //"LoicLavorel_enonce_logiciel_LibreOffice.pdf",
  acronyms: (
    "HEPIA": ("Haute école du paysage, d'ingénierie et d'architecture"),
    "HES-SO": ("Haute école spécialsée de Suisse Occidentale")
  ),
  bibliography-files: "test.bib"
)


= Titre  de niveau 1 <chapter>

== Titre de niveau 2

#lorem(400)

#lorem(400)

== Titre de niveau 2 <title>

Et encore plus de contenu. Vous êtes OK avec ça ?

#lorem(30)

= Titre de niveau 1
#lorem(30)

== Titre de niveau  2

#lorem(50)

=== Titre de niveau 3 <sectiona>

#lorem(30)

==== Titre de niveau 4 (#emoji.warning interdit)

#lorem(30)

==== Titre de niveau 4 (#emoji.warning interdit)

#lorem(30)

=== Titre de niveau 3 <sectionb>

#lorem(30)

== Titre de niveau 2

Voici une référence au @chapter qui est présent sur la #ref(<chapter>, form: "page").

Une référence à la @title qui est présente sur la #ref(<title>, form: "page").

Et le dernier niveau est la @sectiona ou la @sectionb.

A la première utilisation d'un acronyme il sera affiché comme #acr("HEPIA") ou #acr("HES-SO"). A la seconde utilisation des acronymes la forme réduite sera utilisée comme #acr("HEPIA") ou #acr("HES-SO").

Plusieurs papiers peuvent vous aider à avoir une bonne note @kurka2014drives @race2007get. Si vous souhaitez utiliser l'IA il  a là aussi quelques publications à lire @brynjolfsson2025canaries #ref(<fan2025impact>) #ref(label("10.1145/3706598.3713778")).