#import "/src/lib.typ" as hepia
#import "@preview/acrostiche:0.7.0": *

// Lister dans cette table les URLs des figures
#let urls = (
  "www.hesge.ch/hepia/sites/all/themes/hepia/images/logo-hepia.svg",
  "www.hes-so.ch/typo3conf/ext/wng_site/Resources/Public/HES-SO/img/logo_hesso_light.svg"
)

#show: hepia.semester.with(
  title: [Titre de votre mémoire de projet de semestre],
  //short-title: title => [Mon titre cours], //Vous pouvez utiliser une fonction dans ce format pour créer votre titre court (entête de page), sinon le titre est utilisé
  author: (
    firstname: [Prénom],
    lastname: [Nom]
  ),
  date: datetime(day: 1, month: 9, year: 2025), // Saisir la date du dépôt
  teachers: (
    [Prénon1 Nom1],
    [Prénon2 Nom2],
  ),
  clients: (
    [Entreprise 1],
    [Entreprise 2],
  ),
  illustration: (
    illustration: block(height:100%, stroke: 0.5pt, {
      image("/assets/logos/logo-hepia.svg")
      text(9pt)[_Remplacer tout ce_ `block` \ _par votre illustration (fonction image) \ (image non obligatoire)_]
    }),
    legend-source: [Indiquer légende et source de l'image de couverture ici],
  ),
  abstract: [Voici mon résumé, je pourrais aussi faire un `include`. #lorem(250) (*250 mots minimum et 300 mots maximum dans la police utilisée pour votre mémoire*).],
  abstract-illustration: [Insérez ici votre illustration \ (obligatoire)],
  internship: true,
  confidential: true,
  orientation: [Nom complet de votre orientation],
  dedication: [Insérez ici votre dédicace (facultatif), mettre `none` si pas de dédicace],
  acknowledgement: [Formulez ici vos remerciement aux personnes qui vous  on aidé dans la réalisation de votre travail],
  acronyms: (
    "HEPIA": ("Haute école du paysage, d'ingénierie et d'architecture"),
    "HES-SO": ("Haute école spécialsée de Suisse Occidentale")
  ),
  figures_urls: urls,
  introduction: [Insérer ici votre introduction vous pouvez aussi utiliser la fonction `include` pour insérer un fichier séparé],
  conclusion: [Insérer ici votre conclusion vous pouvez aussi utiliser la fonction `include` pour insérer un fichier séparé],
  appendixes: (
    [
      == Titre annexe 1 // Doit être un titre de niveau 2
      Contenu de ma première annexe (utiliser `include` pour un fichier séparé)
    ],
    [
      == Titre annexe 2  <annexe2>  // Doit être un titre de niveau 2
      Contenu de ma deuxième annexe (utiliser `include` pour un fichier séparé)
      // Vous pouvez formater les titres comme vous le shouaitez mais il ne faut pas utiliser les titre de niveau 1 ou 2
      === Titre 1 annexe
      ==== Titre 2 annexe
      === Titre 1 bis annexe
    ],
    //possible d'utiliser include("annexe1.typ") (qui doit commencer par un titre de niveau 2)
  ),
  bibliography-bytes: read("semester.bib", encoding: none)
)

= Titre  de niveau 1 <chapter>

#lorem(50)

== Titre de niveau 2

Voici un texte pour montrer comment la note de bas de page doit être insérée #footnote[Exemple de note de bas de page].

#lorem(200)

=== Titre de niveau 3 <sectiona>

#lorem(30)

==== Titre de niveau 4 (#emoji.warning interdit)

==== Titre de niveau 4 (#emoji.warning interdit)

=== Titre de niveau 3 <sectionb>

#lorem(30)

// Ici on utilise la première URL du tableau comme source (index 0)
#hepia.sourced_figure(caption: [Logo HEPIA], source: [tiré de #hepia.source_url(urls, 0)], image("/assets/logos/logo-hepia.svg"))

#lorem(30)

// Ici on utilise la deuxième url du tableau comme source (index 1)
#hepia.sourced_figure(caption: [Logo HEPIA], source: [tiré de #hepia.source_url(urls, 1)], image("/assets/logos/logo-hes-so-ge.svg"))

#lorem(30)

#hepia.sourced_figure(caption: [Example de predicteurs de citation], source: [tiré de Kurka 2014, p. 9])[
  #table(columns: 2,
    [Predicteur], [Effet],
    [Taille], [positif],
    [Langue anglaise], [positif],
    [Nombre d'auteurs], [négatif],
  )
]


#lorem(30)

#hepia.sourced_figure(caption: [Egalité des OS], source: [réalisé par Guillaume Chanel])[
  #table(columns: 2,
    [OS], [Utilisateur],
    [Microsoft Windows], [100],
    [Linux], [100],
    [MacOS], [100],
  )
]


#lorem(30)

//Sans source (A éviter absolument)
#emoji.warning Ne pas citer de source est interdit:
#hepia.sourced_figure(image("/assets/logos/logo-hepia.svg"), caption: [Logo HEPIA])

#lorem(50)

== Titre de niveau 2 <title>

Et encore plus de contenu. Vous êtes OK avec ça ?

#lorem(30)

= Titre de niveau 1
#lorem(30)

#heading(level: 2)[Titre de niveau  2] #label("test")

#lorem(50)

== Titre de niveau 2

Voici une référence au @chapter qui est présent sur la #ref(<chapter>, form: "page").

Une référence à la @title qui est présente sur la #ref(<title>, form: "page").

Et le dernier niveau est la @sectiona ou la @sectionb.

A la première utilisation d'un acronyme il sera affiché comme #acr("HEPIA") ou #acr("HES-SO"). A la seconde utilisation des acronymes la forme réduite sera utilisée comme #acr("HEPIA") ou #acr("HES-SO").

Plusieurs papiers peuvent vous aider à avoir une bonne note @kurka2014drives @race2007get. Si vous souhaitez utiliser l'IA il  a là aussi quelques publications à lire @brynjolfsson2025canaries #ref(<fan2025impact>) #ref(label("10.1145/3706598.3713778")).

Finalement je souhaite faire référence à l'@annexe2.